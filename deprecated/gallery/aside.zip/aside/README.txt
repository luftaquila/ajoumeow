THEME: Aside - Free Bootstrap 4 Theme
AUTHOR: uiCookies.com
LICENSE: Under Creative Commons 3.0 (probootstrap.com/license)
AUTHOR URI: https://uicookies.com/



CREDITS:

Bootstrap
http://getbootstrap.com/

jQuery
http://jquery.com/

Google Fonts
https://www.google.com/fonts/

Icomoon
https://icomoon.io/app/

Open Iconic
https://useiconic.com/open/

Demo Images
https://unsplash.com

Owl Carousel 2
https://owlcarousel2.github.io/OwlCarousel2/

WayPoint
http://imakewebthings.com/waypoints/

Animate.css
https://daneden.github.io/animate.css/

ImagesLoaded
https://imagesloaded.desandro.com/